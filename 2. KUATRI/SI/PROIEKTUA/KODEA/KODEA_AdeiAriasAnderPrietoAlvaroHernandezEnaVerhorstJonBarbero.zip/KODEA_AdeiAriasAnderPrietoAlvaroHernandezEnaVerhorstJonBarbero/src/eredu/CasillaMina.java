package eredu;

public class CasillaMina extends Casilla{
	public CasillaMina(int x, int y, int bal) {
		super(x,y,bal);
		egoera = new Itxita();
	}
	
	
}
