package eredu;

public class Bandera implements Egoera{
	
}
