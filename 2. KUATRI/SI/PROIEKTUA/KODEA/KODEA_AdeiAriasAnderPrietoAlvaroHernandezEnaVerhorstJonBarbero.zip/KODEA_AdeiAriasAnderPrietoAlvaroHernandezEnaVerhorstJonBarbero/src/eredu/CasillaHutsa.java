package eredu;

public class CasillaHutsa extends Casilla{
	public CasillaHutsa(int x, int y, int bal) {
		super(x,y,bal);
		egoera = new Itxita();
	}
	
	
}
