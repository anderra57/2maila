package eredu;

public interface Egoera {
}
