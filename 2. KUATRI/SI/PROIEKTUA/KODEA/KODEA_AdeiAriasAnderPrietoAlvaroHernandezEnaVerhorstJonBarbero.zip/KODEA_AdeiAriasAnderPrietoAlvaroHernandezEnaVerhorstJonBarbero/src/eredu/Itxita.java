package eredu;

public class Itxita implements Egoera{
	
}
