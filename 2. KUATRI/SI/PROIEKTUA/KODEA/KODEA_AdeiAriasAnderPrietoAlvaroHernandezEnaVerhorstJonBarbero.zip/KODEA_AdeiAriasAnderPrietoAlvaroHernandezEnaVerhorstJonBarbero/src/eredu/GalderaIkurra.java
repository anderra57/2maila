package eredu;

public class GalderaIkurra implements Egoera{

}
