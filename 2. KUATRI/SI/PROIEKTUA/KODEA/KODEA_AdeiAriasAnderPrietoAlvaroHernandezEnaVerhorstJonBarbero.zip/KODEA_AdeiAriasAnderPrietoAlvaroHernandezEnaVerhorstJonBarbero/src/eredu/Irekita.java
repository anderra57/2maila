package eredu;

public class Irekita implements Egoera{

}
