package dragamina;

import bista.Hasieraketa;

public class Nagusia {

	public static void main(String[] args) {
		Hasieraketa hasi = new Hasieraketa();
		hasi.hasiPrograma();
	}

}
