import javax.swing.ImageIcon;
import javax.swing.JPanel;

import java.awt.GridBagLayout;

import javax.swing.JLabel;

public class LuzSemaforo extends JPanel {

	private static final long serialVersionUID = 3049040957332920611L;
	private String color;
	private boolean activo;
	private JLabel lblLuzSemaforo;

	/**SEMAFORO ARGIKO ERAIKITZAILEA*/
	public LuzSemaforo(String pColor, boolean pActivo) {
		super();
		initialize();
		color = pColor.toLowerCase();
		setActivo(pActivo);
	}

	/**PANELA HASIERATU*/
	private void initialize() {
		this.setSize(getPreferredSize());
		this.setLayout(new GridBagLayout());
		this.add(getLblLuzSemaforo());
	}

	
	private JLabel getLblLuzSemaforo() {
		if (lblLuzSemaforo == null) {
			lblLuzSemaforo = new JLabel("");
		}
		return lblLuzSemaforo;
	}

	/** SEMAFORO ARGIA AUKERATU (true- piztuta, false - itzalita)*/
	public void setActivo(boolean pActivo) {
		activo = pActivo;
		
		String nombreImagen;
		
		if (activo) {
			nombreImagen = "circulo_"+color+".png";
		}else {
			nombreImagen = "circulo_apagado.png";
		}
		
		getLblLuzSemaforo().setIcon(new ImageIcon(this.getClass().getResource(nombreImagen)));

	}
}
