public class ProgramaPrincipal {
	public static void main(String[] args) {
		SemaforoCoches sc = new SemaforoCoches();
	}
}
