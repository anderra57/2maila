import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

public class SemaforoCoches extends JFrame  {

	private static final long serialVersionUID = -1526416068663302084L;
	private JPanel contentPane;
	private JPanel pnlSemaforo;
	private LuzSemaforo luzVerde = null;
	private LuzSemaforo luzRoja = null;
	private JLabel lblCont;
	//SEMAFOROEN TXANDAK KUDEATZEKO
	private static final int PERIODO = 15;
	private int cont = PERIODO;
	private boolean estaVerde;
	private Timer timer = null;

	
	public SemaforoCoches() {
		estaVerde = true;
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		initialize();
		//ATAZA: timer bat esleitzen zaio
		TimerTask timerTask = new TimerTask() {	
			@Override
			public void run() {
				actualizarCont();
			}
		};
		//TIMER: segunduro exekutatu "TimerTask" inplementazioa
		timer = new Timer();
		timer.scheduleAtFixedRate(timerTask, 0,1000);
	}
	
	private void initialize() {
		setSize(150, 555);
		this.setContentPane(getContentPane());
		setTitle("Coches");
		setLocationRelativeTo(null);
		setVisible(true);
	}
	

	private void actualizarCont() {
		//DENBORA KONTADOREA EGUNERATU
		cont--;
		if (cont==0) {
			cont = PERIODO;
			estaVerde = !estaVerde;
		}
		// KONTAGAILU LABELA: kolorea aldatu
		if (estaVerde) {
			getLblCont().setForeground(Color.GREEN);
		}
		else {
			getLblCont().setForeground(Color.RED);		
		}
		//KONTAGAILU LABELA: balioa aldatu
		getLblCont().setText(String.valueOf(cont));
		//SEMAFORO ARGIAK: kolorea aldatu
		getLuzVerde().setActivo(estaVerde);
		getLuzRoja().setActivo(!estaVerde);
		//Ereduaren egoera kontsolatik atera
		System.out.printf("EREDUAREN EGOERA-> estaVerde : %b   Cont: %d\n", estaVerde, cont);
	}
	
	public JPanel getContentPane() {
		if (contentPane == null) {
			contentPane = new JPanel();
			contentPane.setLayout(new BorderLayout());
			contentPane.add(getPnlSemaforo(), BorderLayout.CENTER);
		}
		return contentPane;
	}

	private JPanel getPnlSemaforo() {
		if (pnlSemaforo == null) {
			pnlSemaforo = new JPanel();
			pnlSemaforo.setLayout(new GridLayout(4, 1, 0, 10));
			pnlSemaforo.add(getLblCont());
			pnlSemaforo.add(getLuzRoja(),null);
			pnlSemaforo.add(getLuzVerde(),null);
		}
		return pnlSemaforo;
	}
	

	private LuzSemaforo getLuzRoja() {
		if (luzRoja == null) {
			luzRoja = new LuzSemaforo("rojo", true);
		}
		return luzRoja;
	}

	private LuzSemaforo getLuzVerde() {
		if (luzVerde == null) {
			luzVerde = new LuzSemaforo("verde", false);
		}
		return luzVerde;
	}
	
	private JLabel getLblCont() {
		if (lblCont == null) {
			lblCont = new JLabel("15");
			lblCont.setOpaque(true);
			lblCont.setBackground(Color.BLACK);
			lblCont.setFont(new Font("Lucida Grande", Font.BOLD, 72));
			lblCont.setHorizontalAlignment(SwingConstants.CENTER);
			lblCont.setForeground(Color.RED);
		}
		return lblCont;
	}
}
