# -*- coding: utf-8 -*-

from socket import AF_INET, socket, SOCK_STREAM
from threading import Thread


# Metodoak hasieran jartzen dira gero erabiliak izateko ##########################
def handle_client(client):

def broadcast(msg):

##################################################################################


# Programa nagusia ###############################################################
if __name__ == "__main__":

##################################################################################