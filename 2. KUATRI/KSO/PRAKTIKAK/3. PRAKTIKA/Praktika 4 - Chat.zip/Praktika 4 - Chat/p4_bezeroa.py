# -*- coding: utf-8 -*-

from socket import AF_INET, socket, SOCK_STREAM
from threading import Thread
import tkinter


# Metodoak hasieran jartzen dira gero erabiliak izateko ##########################
def receive():

def send(event=None):

def on_closing(event=None):

##################################################################################


# GUI (Graphical User Interface) #################################################
leihoa = tkinter.Tk()
leihoa.title("Chatter")

messages_frame = tkinter.Frame(leihoa)
scrollbar = tkinter.Scrollbar(messages_frame)
msg_listbox = tkinter.Listbox(messages_frame, height=10, width=100)
msg_listbox.configure(yscrollcommand = scrollbar.set)
scrollbar.configure(command = msg_listbox.yview)
scrollbar.pack(side=tkinter.RIGHT, fill=tkinter.Y)
msg_listbox.pack(side=tkinter.LEFT, fill=tkinter.BOTH)
messages_frame.pack()

etiketa = tkinter.Label(leihoa, text="Type your messages here:")
etiketa.pack(side=tkinter.LEFT)
my_msg = tkinter.StringVar()
entry_field = tkinter.Entry(leihoa, width=50, textvariable=my_msg)
entry_field.bind("<Return>", send)
entry_field.pack(side=tkinter.LEFT)
send_button = tkinter.Button(leihoa, text="Send", command=send)
send_button.pack(side=tkinter.LEFT)

leihoa.protocol("WM_DELETE_WINDOW", on_closing)
##################################################################################


# Programa nagusia ###############################################################

##################################################################################
