package jokoa;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;


public class Jokoa {
	
	static String zerbitzaria= "jdbc:mysql://localhost:3306/jokoa";
	static String erabiltzailea= "root";
	static String pasahitza= ""; 
	
	Jokoa() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) throws IOException, ClassNotFoundException, SQLException {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection konexioa= DriverManager.getConnection(zerbitzaria, erabiltzailea, pasahitza);
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		String lerroa;
		int num=99;
		while (num!=0) {
			printMenu();
			lerroa = br.readLine();
			try {
			num = Integer.parseInt(lerroa);
			}catch(Exception e){num=-1;}
			switch(num) {
				case 1:
					jokalariBerriaSartu(konexioa);
					break;
				case 2:
					partidaBerriaSartu(konexioa);
					break;
				case 3:
					jokalariGuztiakInprimatu(konexioa);
					break;
				case 4:
					jokalariaAbizenezBilatu(konexioa);
					break;
				default:   
			}	
		}
		konexioa.close();
 

	}

	private static void jokalariBerriaSartu(Connection konexioa) throws SQLException, IOException {
		System.out.println();
		Statement stm = konexioa.createStatement();
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		System.out.println("Sartu NAN zenbakia:");
		String nan1 = br.readLine();
		
		System.out.println("Sartu izena:");
		String izena1 = br.readLine();
		
		System.out.println("Sartu abizena:");
		String abizena1= br.readLine();
		
		try {
		String query = "insert into jokalaria values ('" + nan1 + "','" + izena1 + "','" + abizena1 + "')";
		stm.executeUpdate(query);
		}	catch(Exception e) {
			System.out.println("Arazoa egon da datua sartzean. Saiatu berriro.");};
		
	}
	
	private static void partidaBerriaSartu(Connection konexioa) throws SQLException, IOException {
		Statement stm = konexioa.createStatement();
		System.out.println();
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	
		String partida2= new Integer((int) new Date().getTime()).toString();

		String data2="2020-02-17";

		System.out.println("Sartu partidaren iraupena:");
		String iraupena2 = br.readLine();
		
		System.out.println("Sartu jokalariaren puntuak:");
		String jokpunt2= br.readLine();
		
		System.out.println("Sartu ordenagailuaren puntuak:");
		String ordpunt2= br.readLine();

		System.out.println("Sartu jokalariaren NAN zenbakia:");
		String nan2 = br.readLine();
		
		try {
		String query = "insert into partida values ('" + partida2 + "','" + data2 + "','" + iraupena2 + "','" + jokpunt2 + "','" + ordpunt2 + "','" + nan2 + "')";
		stm.executeUpdate(query);
		}	catch(Exception e) {
			System.out.println("Arazoa egon da datua sartzean. Saiatu berriro.");};
		
	}

	
	private static void jokalariaAbizenezBilatu(Connection konexioa) throws SQLException, IOException {
		Statement stm = konexioa.createStatement();
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		//String lerroa;
		//lerroa = br.readLine();		
		System.out.println();
		
		System.out.println("Sartu jokalariaren abizena:");
		String abizena4= br.readLine();
		
		
		//ResultSet rs = stm.executeQuery("select izena,abizena,nan from jokalaria where abizena='"+abizena4+"';");
		ResultSet rs = stm.executeQuery("select izena,abizena,nan from jokalaria where abizena='"+abizena4+"' and " + abizena4 + "=@0;");
		
		// hack: 	' or ''='
		// where abizena=xxx AND abizena4=@0 para solucionarlo
		
		while (rs.next())
		{
		    System.out.println (rs.getString(1) + " " + rs.getString(2) + " | " +rs.getString(3) );
		}
		String lerroa = br.readLine();
	}
	
	private static void jokalariGuztiakInprimatu(Connection konexioa) throws SQLException, IOException {
		Statement stm = konexioa.createStatement();
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		//String lerroa;
		//lerroa = br.readLine();		
		System.out.println();
		ResultSet rs = stm.executeQuery("select izena from jokalaria;");
		while (rs.next())
		{
		    System.out.println (rs.getString(1));
		}
		String lerroa = br.readLine();		
	}

	private static void printMenu() {
		System.out.println("");
		System.out.println("+---------------+");
		System.out.println("|     MENUA     |");
		System.out.println("+---------------+");
		System.out.println("");
		System.out.println("Aukeratu:");
		System.out.println("Zer egin nahi duzu?");
		System.out.println("> 1) Jokalari berria sartu");
		System.out.println("> 2) Partida berria sartu");
		System.out.println("> 3) Jokalari guztiak erakutsi");
		System.out.println("> 0) Irten");
		System.out.println();
		
	}

}
