#!/bin/bash

############################################################
#   0) DESINSTALATU 
############################################################
function desinstalatuDena()
{
	echo "#################### desinstalatuDena funtzioa"
}

###########################################################
#   1) APACHE INSTALATU                     
###########################################################
function apacheInstalatu()
{
	echo "#################### apacheInstalatu funtzioa"
}


###########################################################
#   2) WEB APACHE ZERBITZUA PROBATU/TESTEATU         
###########################################################
function apacheTestatu()
{
	echo "#################### apacheTestatu funtzioa"
}

###########################################################
#   3) APACHEn HOST BIRTUAL BAT SORTU
###########################################################
function virtualHostSortu()
{
	echo "#################### virtualHostaSortu funtzioa"
}

###########################################################
#   4) TESTATU BIRTUAL HOSTa
###########################################################
function virtualHostaTestatu()
{
	echo "#################### virtualHostaTestatu funtzioa"
}

###########################################################
#   5) PHP INSTALATU                       
###########################################################
function phpInstalatu()
{
	echo "#################### phpInstalatu funtzioa"
}

###########################################################
#   6) PHP TESTEATU
###########################################################
function phpTestatu()
{
	echo "#################### phpTestatu funtzioa"
}	

############################################################
#    7) PYTHON3 INGURUNE BIRTUALA SORTU
#############################################################
function py3venvSortu()
{
	echo "#################### py3venvSortu funtzioa"
}

############################################################
#   8) APPa INSTALATU
#############################################################
function appaInstalatu()
{
	echo "#################### appaInstalatu funtzioa"
}

#############################################################
#   9) APPa BISTARATU
#############################################################
function appaBistaratu()
{
	echo "#################### appaBistaratu funtzioa"
}

##########################################################
#   10) APACHE ERROREAK BISTARATU
##########################################################
function apacheLogak()
{
	echo "#################### apacheLogak funtzioa"
}

#################################################################
#    11) SSH LOGak KUDEATU 
#################################################################
function sshLogak()
{
	echo "#################### sshLogak funtzioa"
}

###########################################################
#    12) IRTEN                          
###########################################################

function irten()
{
	echo "#################### irten funtzioa"
}

############
### Main ###
############
menukoaukera=0
while test $menukoaukera -ne 12
do
	#Muestra el menu
	echo -e "0 Desinstalatu"
	echo -e "1 Apache instalatu"
	echo -e "2 Apache gaitu eta testatu"
	echo -e "3 Apache host birtuala sortu" 
	echo -e "4 Apache host birtuala testatu" 
	echo -e "5 PHP instalatu"
	echo -e "6 PHP testatu"
	echo -e "7 Python3 ingurune birtuala sortu"
	echo -e "8 APPa instalatu"
	echo -e "9 APPa testatu"
	echo -e "10 Apache erroreak bistaratu"
	echo -e "11 SSH saiakerak bistaratu"
	echo -e "12 Irten"
	read -p "Hautatu ezazu aukera bat: " menukoaukera
	case $menukoaukera in
		0) desinstalatuDena;;
		1) apacheInstalatu;;
		2) apacheTestatu;;
		3) virtualHostSortu;;
		4) virtualHostaTestatu;;
		5) phpInstalatu;;
		6) phpTestatu;;
		7) py3venvSortu;;
		8) appaInstalatu;;
		9) appaBistaratu;;
		10) apacheLogak;;
		11) sshLogak;;
		12) irten;;
		*) ;;
	esac 
done 

echo "SCRIPT-aren amaiera" 
exit 0 
