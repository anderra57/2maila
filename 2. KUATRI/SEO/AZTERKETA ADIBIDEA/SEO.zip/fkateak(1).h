#ifndef _LIBURUTEGIA_1_H
#define _LIBURUTEGIA_1_H
int mystrlen(char kat[]);
#endif
