package aktorePelikulaPackage;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.*;

public class ListaPelikula {
	
	private static ListaPelikula nireListaPelikula = null;
	private HashMap<String,Pelikula> map;
	
	private ListaPelikula(){
		this.map = new HashMap<String,Pelikula>();
	}
	
	public static ListaPelikula getNireListaPelikula(){
		if(nireListaPelikula == null){
			nireListaPelikula = new ListaPelikula();
		}
		return nireListaPelikula;
	}

	public void gehituDirua(String pIzenburua, double pDirua){
		Pelikula pelik = null;
		if(this.map.containsKey(pIzenburua)){
			pelik=this.map.get(pIzenburua);
			pelik.gehituDirua(pDirua);
		}
	}
	
	public int pelikulaKopurua() {
		return this.map.size();
	}
	
	public void erreseteatu() {
		this.map.clear();
	}
	
	public void gehituPelikula(Pelikula pPelikula){
		if(this.bilatuPelikula(pPelikula.getIzenburua())==null){
			this.map.put(pPelikula.getIzenburua(),pPelikula);
		}
	}
	
	public Pelikula bilatuPelikula(String pIzenburua){
		Pelikula pelikula = null;
		if (this.map.containsKey(pIzenburua)){
			pelikula=this.map.get(pIzenburua);
		}
		return pelikula;
	}
	
	public ArrayAktoreak pelikulaBatenListaAktore(String pPeli){
		Pelikula peli = this.bilatuPelikula(pPeli);
		if(peli == null){
			return null;
		}else{
			return peli.getListaAktoreak();
		}
	}
	
	public void fitxeroaErakutsi(String pFitxeroa) throws FileNotFoundException, IOException{
				try{      
					Scanner entrada = new Scanner(new FileReader(pFitxeroa));     
					String linea; 
					Aktore aktor;
					Pelikula peli = null;
					while (entrada.hasNext()) { 
						linea = entrada.nextLine();
						String[] datuak = linea.split("\\s+--->\\s+");
						peli = new Pelikula(datuak[0],45.00);
						ListaPelikula.getNireListaPelikula().gehituPelikula(peli);
						//System.out.println(datuak[0]);
						String[] aktoreak = datuak[1].split("\\s+&&&\\s+");
						int i=0;
						while (i < aktoreak.length){//sartu aktoreak eta pelikulak
							aktor = ListaAktoreak.getNireListaAktoreak().bilatuAktorea(aktoreak[i]);
							if(aktor==null){
								aktor = new Aktore(aktoreak[i]);
								ListaAktoreak.getNireListaAktoreak().gehituAKtorea(aktoreak[i], aktor);														
							}
							//System.out.println(aktoreak[i]);
							peli.listaAktoreanGehitu(aktor);//Hemen, pelikulari aktore hau sartuko diogu bere listaAktorean
							aktor.listaPelikulanGehitu(peli);//Hemen, aktore honi sartuko diogu pelikula hau bere listaPelikulan
							i++;
						}
				      }      
					entrada.close();
				}   catch(IOException e) {e.printStackTrace();}
	}
}
