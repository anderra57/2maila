package aktorePelikulaPackage;

import java.io.FileNotFoundException;
import java.io.IOException;

public class PraktikaHasieratu {

	public static void main(String[] args) throws FileNotFoundException, IOException {
		// TODO Auto-generated method stub
		long inicio = System.currentTimeMillis();
		//Thread.sleep(2000);
		ListaPelikula.getNireListaPelikula().fitxeroaErakutsi("./FilmsActors20162017.txt");	
		Aktore aktore1 = ListaAktoreak.getNireListaAktoreak().bilatuAktorea("Anderson, Sarah-Jane (I)");
		System.out.println(aktore1.getIzenAbizena());
		System.out.println("");
		System.out.println(ListaAktoreak.getNireListaAktoreak().aktoreKopurua());
		Aktore aktore2 = new Aktore("Arias, Adei");
		ListaAktoreak.getNireListaAktoreak().gehituAKtorea("Arias, Adei", aktore2);
		System.out.println(ListaAktoreak.getNireListaAktoreak().aktoreKopurua());
		System.out.println("");
		Pelikula pelikula1 = ListaPelikula.getNireListaPelikula().bilatuPelikula("Togainu no chi");
		System.out.println(pelikula1.getIzenburua());
		System.out.println("");
		System.out.println(ListaPelikula.getNireListaPelikula().pelikulaKopurua());
		Pelikula pelikula2 = new Pelikula("Matrix",00.00);
		ListaPelikula.getNireListaPelikula().gehituPelikula(pelikula2);
		System.out.println(ListaPelikula.getNireListaPelikula().pelikulaKopurua());
		System.out.println("");
		ListaPelikula.getNireListaPelikula().gehituDirua("Macarrones", 10.00);
		Pelikula pelikula3 = ListaPelikula.getNireListaPelikula().bilatuPelikula("Macarrones");
		System.out.println(pelikula3.getDirua());
		System.out.println("");
		ListaAktoreak.getNireListaAktoreak().ezabatuAktorea("Whitlock Jr., Isiah");
		System.out.println("");
		System.out.println("");
		System.out.println(ListaPelikula.getNireListaPelikula().pelikulaKopurua());
		Pelikula pelikula4 = new Pelikula("Eager to Die",00.00);//KASU HONETAN, PELIKULA EZ DA SARTUKO, PELIKULA HAU JADANIK BARRUAN DAGO
		ListaPelikula.getNireListaPelikula().gehituPelikula(pelikula2);
		System.out.println(ListaPelikula.getNireListaPelikula().pelikulaKopurua());
		System.out.println("");
		ListaAktoreak.getNireListaAktoreak().listaOrdenatua();
		System.out.println("");
		ListaAktoreak.getNireListaAktoreak().aktoreakFitxategianSartu();
		
		
		
        long fin = System.currentTimeMillis();
        double tiempo = (double) ((fin - inicio)/1000);
        System.out.println(tiempo +" segundos");
	}

}
