package aktorePelikulaPackage;

import java.util.ArrayList;
import java.util.Iterator;

public class ArrayPelikulak {
	
	private ArrayList<Pelikula> lista;
	
	public ArrayPelikulak(){
		this.lista = new ArrayList<Pelikula>();
	}
	
	private Iterator<Pelikula> getNireIteradorea(){
		return this.lista.iterator();
	}
	
	public boolean badagoPelikula(String pIzenburua){//Pelikula bat emanda, listan dagoen esango digu
		boolean dago = false;
		Pelikula pelikula = null;
		Iterator<Pelikula> itr = this.getNireIteradorea();
		while(itr.hasNext() && !dago){
			pelikula = itr.next();
			if(pelikula.getIzenburua().equals(pIzenburua)){
				dago = true;
			}
		}
		return dago;
	}
	
	public void gehituPelikula(Pelikula pPeli){
			this.lista.add(pPeli);
	}
	
	public int pelikulaKopurua() {
		return this.lista.size();
	}
	
	public void erreseteatu() {
		this.lista.clear();
	}
	
	public void ezabatuAktorea(Aktore pAktore) {
		Pelikula peli = null;
		ArrayAktoreak lista=null;
		Iterator<Pelikula> itr = this.getNireIteradorea();
		while(itr.hasNext()) {
			peli = itr.next();
			lista=peli.getListaAktoreak();
			lista.ezabatuAktorea(pAktore);
		}
	}
}

