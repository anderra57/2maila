package dea3;

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class GraphHashTest {
	GraphHash grafoa;
	ListaAktoreak lista1 = ListaAktoreak.getNireListaAktoreak();	
	ListaPelikula lista2=ListaPelikula.getNireListaPelikula();
	

	@Before
	public void setUp() throws Exception {
		grafoa=new GraphHash();
		lista2.fitxeroaErakutsi("./FilmsActors20162017.txt");
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testGrafoaSortu() {
		grafoa.grafoaSortu(ListaAktoreak.getNireListaAktoreak());
		assertNotNull(grafoa);
	}

	@Test
	public void testPrint() {
		grafoa.print();
	}

	@Test
	public void testKonektatuta() {
		grafoa.grafoaSortu(ListaAktoreak.getNireListaAktoreak());
		assertTrue(grafoa.konektatuta("Devon, Tony","Nutcher, Greg"));
		assertFalse(grafoa.konektatuta("Devon, Tony","Malas, Javi"));
		assertFalse(grafoa.konektatuta("Pearson, Liam","Bardem, Javier"));
		assertFalse(grafoa.konektatuta("Neeson, Liem","Pit, Brad"));
		assertFalse(grafoa.konektatuta("Aho, Miina","Pitt, Brad"));
	}

	@Test
	public void testErlazionatuta() {
		grafoa.grafoaSortu(ListaAktoreak.getNireListaAktoreak());
		ArrayList<String> lista = new ArrayList<String>();//hau erabiliko dugu probetan lista hutsa bat balitz bezala, ez diogulako
		//ezer sartu
		assertNotNull(grafoa.erlazionatuta("Devon, Tony","O'Toole, Peter (I)"));
		assertEquals(grafoa.erlazionatuta("Devon, Tony","Maalas, Javii"),lista);
		assertEquals(grafoa.erlazionatuta("Peaarson, Liiam","Bardem, Javier"),lista);
		assertEquals(grafoa.erlazionatuta("Neeson, Liem","Pit, Brad"),lista);
		assertEquals(grafoa.erlazionatuta("Aho, Miina","Pitt, Brad"),lista);
	}
}
