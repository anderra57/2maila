package dea3;


import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Iterator;

public class Main_Interaktiboa {

	public static void main(String[] args) throws FileNotFoundException, IOException  {
		
		//----------
		
		//long inicio = System.currentTimeMillis();
		//long unekoa = System.currentTimeMillis();
		//long oraingoa;
		//double zatiketa;
		Stopwatch programa = new Stopwatch();
		Stopwatch ekintza = new Stopwatch();
		int num;
		String input;
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		String Linea;
		Pelikula peli1;
		Aktore akt1;
		String a1;
		String a2;
		boolean amaitu=false;
		//----------

		
//----------------------------------------------------------------------------------------
		
		apk2();
		System.out.println("");
		
		//----------
		System.out.println("Kaixo! Sakatu enter programa hasieratzeko");
		Linea=br.readLine();
		
//----------------------------------------------------------------------------------------
		
		//unekoa = System.currentTimeMillis();
		ekintza=new Stopwatch();
		//----------
		
		System.out.println("Aktore eta pelikulen datuak kargatzen...");
		ListaPelikula.getNireListaPelikula().fitxeroaErakutsi("./FilmsActors20162017.txt");
		
		//----------
		//oraingoa = System.currentTimeMillis();
		//zatiketa = ((double) oraingoa - (double) unekoa)/1000;
		System.out.println("Kargatuta! Iraupena: " + ekintza.elapsedTime() +" segundu");
		System.out.println();
		System.out.println("GARRANTZITSUA");
		System.out.println("");
		System.out.println("Aktore bat sartzerako orduan, lehenengo abizena eta gero izena sartu beharko da:");
		System.out.println("Adibidez, Devon, Tony");
		System.out.println("Pelikula bat sartzerako orduan, pelikularen izena sartu beharko da:");
		System.out.println("Adibidez, Eager to Die");
		System.out.println("");
		System.out.println("");
//----------------------------------------------------------------------------------------
		
	do{
		System.out.println("Zer egin nahi duzu?");
		System.out.println("> 1) Aktore kopurua inprimatu");
		System.out.println("> 2) Pelikula kopurua inprimatu");
		System.out.println("> 3) Pelikula baten dirua inprimatu");
		System.out.println("> 4) Aktore bat gehitu");
		System.out.println("> 5) Pelikula bat gehitu");
		System.out.println("> 6) Pelikula bati dirua gehitu");
		System.out.println("> 7) Aktore bat kendu");
		System.out.println("> 8) Aktore lista ordenatuta lortu");
		System.out.println("> 9) Aktore lista fitxategi berri batean sartu");
		System.out.println("> 10) Bi aktore konektatuta daude?");
		System.out.println("> 11) Bi aktoreen arteko lotura inprimatu");
		System.out.println("> ... ");
		System.out.println("> 0) Menutik atera");
		Linea = br.readLine();
		try{
		num = Integer.parseInt(Linea);
		}catch(Exception e){num=-1;}
		
		switch(num){

//cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc		
		case 10:
			
		//----------
			System.out.println("");
			System.out.println("-----------------------------------------------------------");
			System.out.println("");
			System.out.println("Lehen aktorearen izen-abizenak sartu");
			a1= br.readLine();
			System.out.println("Bigarren aktorearen izen-abizenak sartu");
			a2= br.readLine();
			
			GraphHash grafok = new GraphHash();
			grafok.grafoaSortu(ListaAktoreak.getNireListaAktoreak());
			System.out.println("Konexioa bilatzen...");
		//try{
			ekintza=new Stopwatch();
			boolean dago = grafok.konektatuta(a1,a2);
			if(dago){
				System.out.println("");
				System.out.println("BAI, konektatuta daude.");
			}else{
				System.out.println("");
				System.out.println("EZ, ez daude konektatuta.");
			}
			
		//}
		//catch(Exception e){
		//	System.out.println("");
		//	System.out.println("Gutxienez aktore bat grafoan ez dagoenez, EZ daude erlazionatuta.");}
		//catch(OutOfMemoryError e){System.out.println("");
		//System.out.println("Memoria errorea eman du; denbora altua pasa denez, konektatua dagoenean baino hamar aldiz gehiago, konektatuta EZ daudela estima dezakegu.");}
		
		//----------
			System.out.println("");
			System.out.println("Ekintzaren iraupena: " + ekintza.elapsedTime() +" segundu");
			System.out.println("");
			System.out.println("-----------------------------------------------------------");
			System.out.println("");
		
		break;		
		
//cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc		
		
		case 11:
			
			System.out.println("");
			System.out.println("-----------------------------------------------------------");
			System.out.println("");
			System.out.println("Lehen aktorearen izen-abizenak sartu");
			a1= br.readLine();
			System.out.println("Bigarren aktorearen izen-abizenak sartu");
			a2= br.readLine();
		
			GraphHash grafoe = new GraphHash();
			//System.out.println("");
			//System.out.println("Grafoa sortzen...");
			grafoe.grafoaSortu(ListaAktoreak.getNireListaAktoreak());
			//grafo.print();
			/*
			//----------
			oraingoa = System.currentTimeMillis();
			zatiketa = ((double) oraingoa - (double) unekoa)/1000;
			System.out.println("Iraupena: " + zatiketa +" segundu");
				//----------
			unekoa = System.currentTimeMillis();
			//----------
			*/
			
			ekintza=new Stopwatch();
			System.out.println("Erlazioa bilatzen...");
			ArrayList<String> listaErl = grafoe.erlazionatuta(a1,a2);
			if (listaErl==null){
				System.out.println("EZ daude erlazionatuta.");
			}
			else{
				Iterator<String> itr = listaErl.iterator();
				while(itr.hasNext()){
					String izena = itr.next();
					System.out.println(izena);
				}
			}
			
				
			//----------
			
			System.out.println("");
			System.out.println("Ekintzaren iraupena: " + ekintza.elapsedTime() +" segundu");
			System.out.println("");
			System.out.println("-----------------------------------------------------------");
			System.out.println("");
			
			break;
			
//cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
			
		case 1:
			ekintza=new Stopwatch();
			System.out.println("");
			System.out.println("-----------------------------------------------------------");
			System.out.println("");
			System.out.println("Guztira, "+ListaAktoreak.getNireListaAktoreak().aktoreKopurua()+" aktore daude gure datu basean");
			
			//----------
			
			System.out.println("");
			System.out.println("Ekintzaren iraupena: " + ekintza.elapsedTime() +" segundu");
			System.out.println("");
			System.out.println("-----------------------------------------------------------");
			System.out.println("");
			
			break;
			
//cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
			
		case 2:
			ekintza=new Stopwatch();
			System.out.println("");
			System.out.println("Guztira, "+ListaPelikula.getNireListaPelikula().pelikulaKopurua()+" pelikula daude gure datu basean");
			
			//----------
			
			System.out.println("");
			System.out.println("Ekintzaren iraupena: " + ekintza.elapsedTime() +" segundu");
			System.out.println("");
			System.out.println("-----------------------------------------------------------");
			System.out.println("");
			
			break;
			
//cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
			
		case 3:
			
			System.out.println("");
			System.out.println("-----------------------------------------------------------");
			System.out.println("");
			System.out.println("Pelikularen izenburua sartu:");
			System.out.println("");
			input= br.readLine();
			peli1 = ListaPelikula.getNireListaPelikula().bilatuPelikula(input);
			ekintza=new Stopwatch();
			double diru=peli1.getDirua();
			System.out.println(input+" pelikulak " + diru+ "$-ko aurrekontua dauka.");			
			
			//----------
			
			System.out.println("");
			System.out.println("Ekintzaren iraupena: " + ekintza.elapsedTime() +" segundu");
			System.out.println("");
			System.out.println("-----------------------------------------------------------");
			System.out.println("");
			
			break;
			
//cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
		
		case 4:
			System.out.println("");
			System.out.println("-----------------------------------------------------------");
			System.out.println("");
			System.out.println("Aktorearen izena sartu:");
			System.out.println("");
			input= br.readLine();
			akt1=new Aktore(input);
			ekintza=new Stopwatch();
			if(ListaAktoreak.getNireListaAktoreak().bilatuAktorea(input)==null){
				ListaAktoreak.getNireListaAktoreak().gehituAKtorea(input,akt1);
				System.out.println("Aktorea datu basera gehitu da.");
			}
			else{System.out.println("Aktorea datu basean bazegoen jada.");}
			
			//----------
			
			System.out.println("");
			System.out.println("Ekintzaren iraupena: " + ekintza.elapsedTime() +" segundu");
			System.out.println("");
			System.out.println("-----------------------------------------------------------");
			System.out.println("");
			
			break;
			
//cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
			
		case 5:
			System.out.println("");
			System.out.println("-----------------------------------------------------------");
			System.out.println("");
			System.out.println("Pelikularen izenburua sartu:");
			System.out.println("");
			input= br.readLine();
			peli1=new Pelikula(input,999999.99);
			ekintza=new Stopwatch();
			if(ListaPelikula.getNireListaPelikula().bilatuPelikula(input)==null){
				ListaPelikula.getNireListaPelikula().gehituPelikula(peli1);
				System.out.println("Pelikula datu basera gehitu da.");
			}
			else{System.out.println("Pelikula datu basean bazegoen jada.");}
			
			//----------
			
			System.out.println("");
			System.out.println("Ekintzaren iraupena: " + ekintza.elapsedTime() +" segundu");
			System.out.println("");
			System.out.println("-----------------------------------------------------------");
			System.out.println("");
			
			break;
			
//cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
			
		case 6:
			System.out.println("");
			System.out.println("-----------------------------------------------------------");
			System.out.println("");
			System.out.println("Pelikularen izenburua sartu:");
			input= br.readLine();
			String izen=input;
			peli1=new Pelikula(input,999999.99);
			ekintza=new Stopwatch();
			if(ListaPelikula.getNireListaPelikula().bilatuPelikula(input)==null){
				
				System.out.println("Pelikula ez dago datu basean, saiatu berriz.");
			}
			else{
				System.out.println("Pelikularen aurrekontua sartu:");
				System.out.println("");
				input= br.readLine();
				double diruplus=Double.parseDouble(input);
				ListaPelikula.getNireListaPelikula().gehituDirua(izen, diruplus);
				System.out.println("Pelikularen aurrekontua datu basera gehitu da.");	
			}
			
			
			//----------
			
			System.out.println("");
			System.out.println("Ekintzaren iraupena: " + ekintza.elapsedTime() +" segundu");
			System.out.println("");
			System.out.println("-----------------------------------------------------------");
			System.out.println("");
			
			break;
			
//cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
			
		case 7:
			System.out.println("");
			System.out.println("-----------------------------------------------------------");
			System.out.println("");
			System.out.println("Aktorearen izena sartu:");
			System.out.println("");
			input= br.readLine();
			akt1=new Aktore(input);
			ekintza=new Stopwatch();
			if(ListaAktoreak.getNireListaAktoreak().bilatuAktorea(input)!=null){
				ListaAktoreak.getNireListaAktoreak().ezabatuAktorea(input);
				System.out.println("Aktorea datu basetik ezabatu da.");
			}
			else{System.out.println("Aktorea datu basean ez zegoen jada.");}
			
			//----------
			
			System.out.println("");
			System.out.println("Ekintzaren iraupena: " + ekintza.elapsedTime() +" segundu");
			System.out.println("");
			System.out.println("-----------------------------------------------------------");
			System.out.println("");
			
			break;
			
//cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
			
		case 8:
			System.out.println("");
			System.out.println("-----------------------------------------------------------");
			System.out.println("");
			ekintza=new Stopwatch();
			ListaAktoreak.getNireListaAktoreak().listaOrdenatua();
			System.out.println("Aktoreen lista ordenatu da.");
			
			//----------
			
			System.out.println("");
			System.out.println("Ekintzaren iraupena: " + ekintza.elapsedTime() +" segundu");
			System.out.println("");
			System.out.println("-----------------------------------------------------------");
			System.out.println("");
			
			break;
			
//cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
			
		case 9:
			System.out.println("");
			System.out.println("-----------------------------------------------------------");
			System.out.println("");
			System.out.println("Fitxategiaren izena sartu:");
			System.out.println("");
			input= br.readLine();	
			ekintza=new Stopwatch();
			ListaAktoreak.getNireListaAktoreak().aktoreakFitxategianSartu();
			System.out.println("Aktoreekin fitxategia sortu da.");
			
			//----------
			
			System.out.println("");
			System.out.println("Ekintzaren iraupena: " + ekintza.elapsedTime() +" segundu");
			System.out.println("");
			System.out.println("-----------------------------------------------------------");
			System.out.println("");
			
			break;
			
//cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc			
		case 0:
			System.out.println("");
			System.out.println("-----------------------------------------------------------");
		    //long fin = System.currentTimeMillis();
		    //long tiempo = ((fin - inicio)/1000);
			amaitu=true;
		    long tiempo=(long)programa.elapsedTime();
		    System.out.println("");
		    System.out.println("Agur!");
		    System.out.println("");
		    System.out.println("Sesioaren iraupen totala:");
		    if  (tiempo>59){
		    	System.out.println(tiempo/60 +" min " + tiempo % 60 + " s");
		    }
		    else{
		    System.out.println(tiempo +" segundu");}
		    System.out.println("");
		    System.out.println("-----------------------------------------------------------");
		    System.out.println();
			
		    break;
		    
//cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc		
		default:
			System.out.println("");
			System.out.println("Ongi sartu digitua!");
			System.out.println("");
			System.out.println("-----------------------------------------------------------");
			System.out.println("");
			break;
		}	
//cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc		
	  
		
		//----------
			if(!amaitu){
				System.out.println("Sakatu enter jarraitzeko");
				Linea=br.readLine();
			}
	}while(num!=0);
		
		
//----------------------------------------------------------------------------------------			
	}

	private static void apk(){
		System.out.println("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
		System.out.println("+                                                                      +");
		System.out.println("+   █████╗ ██╗  ██╗████████╗ ██████╗ ██████╗ ███████╗ █████╗ ██╗  ██╗  + ");
		System.out.println("+  ██╔══██╗██║ ██╔╝╚══██╔══╝██╔═══██╗██╔══██╗██╔════╝██╔══██╗██║ ██╔╝  +");
		System.out.println("+  ███████║█████╔╝    ██║   ██║   ██║██████╔╝█████╗  ███████║█████╔╝   +");
		System.out.println("+  ██╔══██║██╔═██╗    ██║   ██║   ██║██╔══██╗██╔══╝  ██╔══██║██╔═██╗   +");
		System.out.println("+  ██║  ██║██║  ██╗   ██║   ╚██████╔╝██║  ██║███████╗██║  ██║██║  ██╗  +");
		System.out.println("+  ╚═╝  ╚═╝╚═╝  ╚═╝   ╚═╝    ╚═════╝ ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝  +");
		System.out.println("+                                                                      +");
		System.out.println("+                     ███████╗████████╗ █████╗                         +");
		System.out.println("+                     ██╔════╝╚══██╔══╝██╔══██╗                        +");
		System.out.println("+                     █████╗     ██║   ███████║                        +");
		System.out.println("+                     ██╔══╝     ██║   ██╔══██║                        +");
		System.out.println("+                     ███████╗   ██║   ██║  ██║                        +");
		System.out.println("+                     ╚══════╝   ╚═╝   ╚═╝  ╚═╝                        +");
		System.out.println("+                                                                      +");
		System.out.println("+ ██████╗ ███████╗██╗     ██╗██╗  ██╗██╗   ██╗██╗      █████╗ ██╗  ██╗ +");
		System.out.println("+ ██╔══██╗██╔════╝██║     ██║██║ ██╔╝██║   ██║██║     ██╔══██╗██║ ██╔╝ +");
		System.out.println("+ ██████╔╝█████╗  ██║     ██║█████╔╝ ██║   ██║██║     ███████║█████╔╝  +");
		System.out.println("+ ██╔═══╝ ██╔══╝  ██║     ██║██╔═██╗ ██║   ██║██║     ██╔══██║██╔═██╗  +");
		System.out.println("+ ██║     ███████╗███████╗██║██║  ██╗╚██████╔╝███████╗██║  ██║██║  ██╗ +");
		System.out.println("+ ╚═╝     ╚══════╝╚══════╝╚═╝╚═╝  ╚═╝ ╚═════╝ ╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝ +");
		System.out.println("+                                                                      +");
		System.out.println("+     ██╗  ██╗██╗   ██╗██████╗ ███████╗ █████╗ ████████╗██╗   ██╗      +");
		System.out.println("+     ██║ ██╔╝██║   ██║██╔══██╗██╔════╝██╔══██╗╚══██╔══╝██║   ██║      +");
		System.out.println("+     █████╔╝ ██║   ██║██║  ██║█████╗  ███████║   ██║   ██║   ██║      +");
		System.out.println("+     ██╔═██╗ ██║   ██║██║  ██║██╔══╝  ██╔══██║   ██║   ██║   ██║      +");
		System.out.println("+     ██║  ██╗╚██████╔╝██████╔╝███████╗██║  ██║   ██║   ╚██████╔╝      +");
		System.out.println("+     ╚═╝  ╚═╝ ╚═════╝ ╚═════╝ ╚══════╝╚═╝  ╚═╝   ╚═╝    ╚═════╝       +");
		System.out.println("+                                                                      +");
		System.out.println("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
		
	}
	
	private static void apk2(){
		System.out.println("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
		System.out.println("+                                                                                                                                     +");  
		
		System.out.println("+                  █████╗ ██╗  ██╗████████╗ ██████╗ ██████╗ ███████╗ █████╗ ██╗  ██╗    ███████╗████████╗ █████╗                      +");
		System.out.println("+                 ██╔══██╗██║ ██╔╝╚══██╔══╝██╔═══██╗██╔══██╗██╔════╝██╔══██╗██║ ██╔╝    ██╔════╝╚══██╔══╝██╔══██╗                     +");
		System.out.println("+                 ███████║█████╔╝    ██║   ██║   ██║██████╔╝█████╗  ███████║█████╔╝     █████╗     ██║   ███████║                     +");
		System.out.println("+                 ██╔══██║██╔═██╗    ██║   ██║   ██║██╔══██╗██╔══╝  ██╔══██║██╔═██╗     ██╔══╝     ██║   ██╔══██║                     +");
		System.out.println("+                 ██║  ██║██║  ██╗   ██║   ╚██████╔╝██║  ██║███████╗██║  ██║██║  ██╗    ███████╗   ██║   ██║  ██║                     +");
		System.out.println("+                 ╚═╝  ╚═╝╚═╝  ╚═╝   ╚═╝    ╚═════╝ ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝    ╚══════╝   ╚═╝   ╚═╝  ╚═╝                     +");
		System.out.println("+                                                                                                                                     +");  
		System.out.println("+ ██████╗ ███████╗██╗     ██╗██╗  ██╗██╗   ██╗██╗      █████╗ ██╗  ██╗    ██╗  ██╗██╗   ██╗██████╗ ███████╗ █████╗ ████████╗██╗   ██╗ +");
		System.out.println("+ ██╔══██╗██╔════╝██║     ██║██║ ██╔╝██║   ██║██║     ██╔══██╗██║ ██╔╝    ██║ ██╔╝██║   ██║██╔══██╗██╔════╝██╔══██╗╚══██╔══╝██║   ██║ +");
		System.out.println("+ ██████╔╝█████╗  ██║     ██║█████╔╝ ██║   ██║██║     ███████║█████╔╝     █████╔╝ ██║   ██║██║  ██║█████╗  ███████║   ██║   ██║   ██║ +");
		System.out.println("+ ██╔═══╝ ██╔══╝  ██║     ██║██╔═██╗ ██║   ██║██║     ██╔══██║██╔═██╗     ██╔═██╗ ██║   ██║██║  ██║██╔══╝  ██╔══██║   ██║   ██║   ██║ +");
		System.out.println("+ ██║     ███████╗███████╗██║██║  ██╗╚██████╔╝███████╗██║  ██║██║  ██╗    ██║  ██╗╚██████╔╝██████╔╝███████╗██║  ██║   ██║   ╚██████╔╝ +");
		System.out.println("+ ╚═╝     ╚══════╝╚══════╝╚═╝╚═╝  ╚═╝ ╚═════╝ ╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝    ╚═╝  ╚═╝ ╚═════╝ ╚═════╝ ╚══════╝╚═╝  ╚═╝   ╚═╝    ╚═════╝  +");
		
		System.out.println("+                                                                                                                                     +");  
		System.out.println("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
		
	}
}
