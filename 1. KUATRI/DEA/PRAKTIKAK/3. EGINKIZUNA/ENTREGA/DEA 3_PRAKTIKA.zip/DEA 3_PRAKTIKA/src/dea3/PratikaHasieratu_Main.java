package dea3;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;

public class PratikaHasieratu_Main {
	
	private void erlazioaInprimatu(ArrayList<String> lista){
		Iterator<String> itr = lista.iterator();
		while(itr.hasNext()){
			String izena = itr.next();
			System.out.println(izena);
		}
	}
	public static void main(String[] args) throws FileNotFoundException, IOException{
		PratikaHasieratu_Main prak = new PratikaHasieratu_Main();
		ArrayList<String> emaitza;
		
		System.out.println("PRAKTIKAREN HASIERA:");
		System.out.println("");
		System.out.println("FITXATEGIA KARGATZEN ARI DA");
		Stopwatch fitx = new Stopwatch();
		ListaPelikula.getNireListaPelikula().fitxeroaErakutsi("./FilmsActors20162017.txt");
		System.out.println(fitx.elapsedTime()+" segundu behar izan ditu");
		System.out.println("");
		
		
		GraphHash grafoa = new GraphHash();
		System.out.println("GRAFOA SORTZEN ARI DA");
		Stopwatch graf = new Stopwatch();
		grafoa.grafoaSortu(ListaAktoreak.getNireListaAktoreak());
		System.out.println(graf.elapsedTime()+" segundu behar izan ditu");
		System.out.println("");
		System.out.println("GRAFOA KARGATU DA");
		System.out.println("");
		System.out.println("");
		
		
		boolean konek;
		System.out.println("KONEKTATU METODOA:");
		System.out.println("");
		System.out.println("BI AKTOREAK PELIKULA BERDINEAN DAUDENEAN, TRUE EMAN BEHAR DU");
		Stopwatch denbora0 = new Stopwatch();
		konek = grafoa.konektatuta("Devon, Tony", "O'Toole, Peter (I)");
		System.out.println(konek);
		System.out.println(denbora0.elapsedTime()+" segundu behar izan ditu");
		System.out.println("");
		System.out.println("BI AKTOREAK EZ DAUDE PELIKULA BERDINEAN, BAINA KONEKTATUTA DAUDE");
		Stopwatch denbora1 = new Stopwatch();
		konek = grafoa.konektatuta("Devon, Tony", "Ruoss, Anya");
		System.out.println(konek);
		System.out.println(denbora1.elapsedTime()+" segundu behar izan ditu");
		System.out.println("");
		System.out.println("BI AKTOREAK EZ DAUDE KONEKTATUTA, FALSE EMANGO DU");
		Stopwatch denbora2 = new Stopwatch();
		konek = grafoa.konektatuta("Devon, Tony", "Alonso, Nadia");
		System.out.println(konek);
		System.out.println(denbora2.elapsedTime()+" segundu behar izan ditu");
		System.out.println("");
		System.out.println("");
		
		System.out.println("ORAIN IKUSIKO DUGU AKTOREAK ALEATORIOKI 100 ALDIZ HARTUZ ZENBAT KONEKTATUTA DAUDEN:");
		System.out.println("Minutu eta erdi iraun dezake");
		int kont = 0;
		Object[] values = ListaAktoreak.getNireListaAktoreak().getLista().values().toArray();
		Random aleatorioa = new Random();
		Stopwatch denbora = new Stopwatch();
		for(int i=0;i<100;i++){
			Aktore randomValue1 = (Aktore) values[aleatorioa.nextInt(values.length)];
			Aktore randomValue2 = (Aktore) values[aleatorioa.nextInt(values.length)];
			String a =randomValue1.getIzenAbizena(); 
			String b =randomValue2.getIzenAbizena();
			if(!a.equals(b)){
				boolean kon = grafoa.konektatuta(a, b);
				if(kon){
					kont++;
				}
			}
		}
		System.out.println("Konektatu metodoa 100 aldiz exekutatuta "+kont+" true izan dira");
		System.out.println("");
		System.out.println(denbora.elapsedTime()+" segundu behar izan ditu");
		System.out.println("");
		System.out.println("");
		System.out.println("BUKATU DA KONEKTATU");
		System.out.println("");
		System.out.println("");
		
		
		System.out.println("ERLAZIONATU METODOA:");
		System.out.println("");
		System.out.println("BI AKTOREAK PELIKULA BERDINEAN DAUDENEAN");
		Stopwatch denbora5 = new Stopwatch();
		emaitza = grafoa.erlazionatuta("Devon, Tony", "O'Toole, Peter (I)");
		System.out.println("EMAITZA INPRIMATUKO DUGU:");
		prak.erlazioaInprimatu(emaitza);
		System.out.println(denbora5.elapsedTime()+" segundu behar izan ditu");
		System.out.println("");
		System.out.println("BI AKTOREAK EZ DAUDE PELIKULA BERDINEAN, BAINA ERLAZIONATUTA DAUDE");
		Stopwatch denbora3 = new Stopwatch();
		emaitza = grafoa.erlazionatuta("Devon, Tony", "Ruoss, Anya");
		System.out.println("EMAITZA INPRIMATUKO DUGU:");
		prak.erlazioaInprimatu(emaitza);
		System.out.println(denbora3.elapsedTime()+" segundu behar izan ditu");
		System.out.println("");
		System.out.println("BI AKTOREAK EZ DAUDE KONEKTATUTA");
		Stopwatch denbora4 = new Stopwatch();
		grafoa.erlazionatuta("Devon, Tony", "Alonso, Nadia");
		System.out.println(denbora4.elapsedTime()+" segundu behar izan ditu");
		System.out.println("");
		System.out.println("");	
		
		System.out.println("ORAIN IKUSIKO DUGU AKTOREAK ALEATORIOKI 10 ALDIZ HARTUZ, KONEKTATUTA BALEUDE, HAUEN ERLAZIOA AGERTUKO LITZATEKE:");
		System.out.println("ORAIN EZ DUGU INPRIMATUKO, DENBORA GEHIAGO BEHARKO ZUKEELAKO");
		Stopwatch denbora7 = new Stopwatch();
		for(int i=0;i<10;i++){
			Aktore randomValue1 = (Aktore) values[aleatorioa.nextInt(values.length)];
			Aktore randomValue2 = (Aktore) values[aleatorioa.nextInt(values.length)];
			String a =randomValue1.getIzenAbizena(); 
			String b =randomValue2.getIzenAbizena();
			grafoa.erlazionatuta(a, b);
			/*emaitza = grafoa.erlazionatuta(a, b);
			prak.erlazioaInprimatu(emaitza);*/
		}
		System.out.println(denbora7.elapsedTime()+" segundu behar izan ditu 10 erlazioak gauzatzeko");
		System.out.println("");
		System.out.println("");
		System.out.println("BUKATU DA ERLAZIONATU");
		System.out.println("");
		System.out.println("");
		
		
		System.out.println("BUKATU DA PRAKTIKA");
	}
}