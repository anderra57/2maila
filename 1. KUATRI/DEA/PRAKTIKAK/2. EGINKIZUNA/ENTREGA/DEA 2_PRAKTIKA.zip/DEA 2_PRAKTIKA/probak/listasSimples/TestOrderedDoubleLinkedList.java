package listasSimples;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import listasSimples.OrderedDoubleLinkedList;

public class TestOrderedDoubleLinkedList {
	OrderedDoubleLinkedList<Integer> lista1;
	OrderedDoubleLinkedList<Integer> lista2;
	@Before
	public void setUp() throws Exception {
		lista1 = new OrderedDoubleLinkedList<Integer>();
		lista2 = new OrderedDoubleLinkedList<Integer>();
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testAdd() {
		lista1.add(3);
		lista1.add(1);
		lista1.add(5);
		lista1.add(7);
		lista1.add(9);
		lista1.add(2);
		lista1.add(45);
		assertEquals(lista1.size(), 7);
		lista1.adabegiakInprimatu();
		System.out.println("9 elementua kenduz gero");
		lista1.remove(9);
		assertEquals(lista1.size(), 6);
		lista1.adabegiakInprimatu();
	}

	@Test
	public void testMerge() {
		System.out.println("LEHENENGO LISTA:");
		lista1.add(3);
		lista1.add(1);
		lista1.add(5);
		lista1.add(7);
		lista1.add(9);
		lista1.add(2);
		lista1.add(45);
		lista1.adabegiakInprimatu();
		System.out.println("");
		System.out.println("BIGARREN LISTA:");
		lista2.add(2);
		lista2.add(67);
		lista2.add(1);
		lista2.add(8);
		lista2.add(6);
		lista2.add(0);
		lista2.add(4);
		lista2.adabegiakInprimatu();
		System.out.println("");
		System.out.println("BI LISTEN ARTEKO MERGE-A EGIN ONDOREN:");
		lista1.merge(lista2);
		
	}
}
