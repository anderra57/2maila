package listasSimples;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import listasSimples.UnorderedDoubleLinkedList;

public class TestUnorderedDoubleLinkedList {
	
	UnorderedDoubleLinkedList<Integer> listaZenbaki1;
	@Before
	public void setUp() throws Exception {
		listaZenbaki1 = new UnorderedDoubleLinkedList<Integer>();
		
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testAddToFront() {
		assertTrue(listaZenbaki1.isEmpty());
		assertEquals(listaZenbaki1.count,0);
		listaZenbaki1.addToFront(1);
		assertFalse(listaZenbaki1.isEmpty());
		listaZenbaki1.adabegiakInprimatu();
		listaZenbaki1.addToFront(2);
		listaZenbaki1.addToFront(3);
		listaZenbaki1.addToFront(4);
		listaZenbaki1.addToFront(5);
		listaZenbaki1.addToFront(6);
		listaZenbaki1.addToFront(7);
		assertEquals(listaZenbaki1.count,7);
		listaZenbaki1.adabegiakInprimatu();
	}

	@Test
	public void testAddToRear() {
		assertTrue(listaZenbaki1.isEmpty());
		assertEquals(listaZenbaki1.count,0);
		listaZenbaki1.addToRear(1);
		assertFalse(listaZenbaki1.isEmpty());
		assertEquals(listaZenbaki1.count,1);
		listaZenbaki1.adabegiakInprimatu();
		listaZenbaki1.addToRear(2);
		listaZenbaki1.addToRear(3);
		listaZenbaki1.addToRear(4);
		listaZenbaki1.addToRear(5);
		listaZenbaki1.addToRear(6);
		listaZenbaki1.addToRear(7);
		assertEquals(listaZenbaki1.count,7);
		listaZenbaki1.adabegiakInprimatu();
	}

	@Test
	public void testAddAfter() {
		assertTrue(listaZenbaki1.isEmpty());
		listaZenbaki1.addAfter(1,null);
		assertFalse(listaZenbaki1.isEmpty());
		listaZenbaki1.addAfter(2,1);
		listaZenbaki1.addAfter(3,2);
		listaZenbaki1.addAfter(4,3);
		listaZenbaki1.addAfter(5,4);
		listaZenbaki1.addAfter(6,5);
		listaZenbaki1.addAfter(7,6);
		assertEquals(listaZenbaki1.count,7);
		System.out.println("8 elementua, 6 elementuaren ondoren txertatu");
		listaZenbaki1.addAfter(8,6);
		listaZenbaki1.adabegiakInprimatu();
	}
}
