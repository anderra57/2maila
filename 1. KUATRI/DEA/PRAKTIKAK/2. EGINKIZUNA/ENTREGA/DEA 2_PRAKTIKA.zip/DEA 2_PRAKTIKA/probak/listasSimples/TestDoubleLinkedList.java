package listasSimples;

import static org.junit.Assert.*;

import java.util.Iterator;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import listasSimples.UnorderedDoubleLinkedList;

public class TestDoubleLinkedList {
	UnorderedDoubleLinkedList<Integer> listaZenbaki1;
	UnorderedDoubleLinkedList<Integer> listaZenbaki2;

	@Before
	public void setUp() throws Exception {
		listaZenbaki1 = new UnorderedDoubleLinkedList<Integer>();
		listaZenbaki2 = new UnorderedDoubleLinkedList<Integer>();
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testSetDeskr() {
		listaZenbaki1.setDeskr("lista1");
		assertNotNull(listaZenbaki1.getDeskr());
	}

	@Test
	public void testGetDeskr() {
		listaZenbaki1.setDeskr("lista1");
		assertEquals(listaZenbaki1.getDeskr(),"lista1");
	}

	@Test
	public void testRemoveFirst() {
		//elementu asko
		listaZenbaki1.addToRear(1);
		listaZenbaki1.addToRear(2);
		listaZenbaki1.addToRear(3);
		listaZenbaki1.addToRear(4);
		listaZenbaki1.addToRear(5);
		listaZenbaki1.addToRear(6);
		listaZenbaki1.addToRear(7);
		listaZenbaki1.removeFirst();
		assertEquals(listaZenbaki1.first.data,new Integer(2));
		//elementu bakarra
		listaZenbaki2.addToRear(1);
		listaZenbaki2.removeFirst();
		assertNull(listaZenbaki2.first);
	}

	@Test
	public void testRemoveLast() {
		//elementu asko
		listaZenbaki1.addToRear(1);
		listaZenbaki1.addToRear(2);
		listaZenbaki1.addToRear(3);
		listaZenbaki1.addToRear(4);
		listaZenbaki1.addToRear(5);
		listaZenbaki1.addToRear(6);
		listaZenbaki1.addToRear(7);
		listaZenbaki1.removeLast();
		assertEquals(listaZenbaki1.first.prev.data,new Integer(6));
		//elementu bakarra
		listaZenbaki2.addToRear(1);
		listaZenbaki2.removeLast();
		assertNull(listaZenbaki2.first);			
	}

	@Test
	public void testRemove() {
		//elementu asko
		listaZenbaki1.addToRear(1);
		listaZenbaki1.addToRear(2);
		listaZenbaki1.addToRear(3);
		listaZenbaki1.addToRear(4);
		listaZenbaki1.addToRear(5);
		listaZenbaki1.addToRear(6);
		listaZenbaki1.addToRear(7);
		listaZenbaki1.remove(5);
		assertFalse(listaZenbaki1.contains(5));
		//elementu bakarra
		listaZenbaki2.addToRear(1);
		listaZenbaki2.remove(1);
		assertFalse(listaZenbaki2.contains(1));		
			
	}

	@Test
	public void testFirst() {
		listaZenbaki1.addToRear(1);
		listaZenbaki1.addToRear(2);
		listaZenbaki1.addToRear(3);
		listaZenbaki1.addToRear(4);
		listaZenbaki1.addToRear(5);
		assertEquals(listaZenbaki1.first(), new Integer(1));
	}

	@Test
	public void testLast() {
		listaZenbaki1.addToRear(1);
		listaZenbaki1.addToRear(2);
		listaZenbaki1.addToRear(3);
		listaZenbaki1.addToRear(4);
		listaZenbaki1.addToRear(5);
		assertEquals(listaZenbaki1.last(), new Integer(5));
	}

	@Test
	public void testContains() {
		//elementu asko
		listaZenbaki1.addToRear(1);
		listaZenbaki1.addToRear(2);
		listaZenbaki1.addToRear(3);
		listaZenbaki1.addToRear(4);
		listaZenbaki1.addToRear(5);
		listaZenbaki1.addToRear(6);
		listaZenbaki1.addToRear(7);
		assertTrue(listaZenbaki1.contains(5));
		assertFalse(listaZenbaki1.contains(53));
		//elementu bakarra
		listaZenbaki2.addToRear(1);
		assertTrue(listaZenbaki2.contains(1));
		assertFalse(listaZenbaki2.contains(5));
	}

	@Test
	public void testFind() {
		//elementu asko
		listaZenbaki1.addToRear(1);
		listaZenbaki1.addToRear(2);
		listaZenbaki1.addToRear(3);
		listaZenbaki1.addToRear(4);
		listaZenbaki1.addToRear(5);
		listaZenbaki1.addToRear(6);
		listaZenbaki1.addToRear(7);
		assertEquals(listaZenbaki1.find(3),new Integer(3));
		assertNotEquals(listaZenbaki1.find(43),new Integer(43));
		//elementu bakarra
		listaZenbaki2.addToRear(1);
		assertEquals(listaZenbaki2.find(1),new Integer(1));
		assertNotEquals(listaZenbaki2.find(43),new Integer(43));
	}

	@Test
	public void testIsEmpty() {
		listaZenbaki1.addToRear(1);
		assertEquals(listaZenbaki1.size(),1);
		listaZenbaki1.removeLast();
		assertEquals(listaZenbaki1.size(),0);
		assertTrue(listaZenbaki1.isEmpty());
	}

	@Test
	public void testSize() {
		//elementu asko
		listaZenbaki1.addToRear(1);
		listaZenbaki1.addToRear(2);
		listaZenbaki1.addToRear(3);
		listaZenbaki1.addToRear(4);
		listaZenbaki1.addToRear(5);
		listaZenbaki1.addToRear(6);
		listaZenbaki1.addToRear(7);
		assertEquals(listaZenbaki1.size(),7);
		listaZenbaki1.remove(5);
		listaZenbaki1.remove(4);
		assertEquals(listaZenbaki1.size(),5);
		//elementu bakarra
		listaZenbaki2.addToRear(1);
		assertEquals(listaZenbaki2.size(),1);
		//hutsa
		listaZenbaki2.remove(1);
		assertEquals(listaZenbaki2.size(),0);
	}

	@Test
	public void testIterator() {
		listaZenbaki1.addToRear(1);
		listaZenbaki1.addToRear(2);
		listaZenbaki1.addToRear(3);
		listaZenbaki1.addToRear(4);
		listaZenbaki1.addToRear(5);
		listaZenbaki1.addToRear(6);
		listaZenbaki1.addToRear(7);
		listaZenbaki1.adabegiakInprimatu();
		Iterator<Integer> itr = listaZenbaki1.iterator();
		while(itr.hasNext()){
			int datua = itr.next();
			System.out.println(datua);
		}
		assertNotNull(listaZenbaki1.iterator());
		
	}

}
