package listasSimples;
import java.util.*;

public class ArrayAktoreak {
	
	private UnorderedDoubleLinkedList<Aktore> lista;
	
	public ArrayAktoreak(){
		this.lista = new UnorderedDoubleLinkedList<Aktore>();
	}
	
	private Iterator<Aktore> getNireIteradorea(){
		return this.lista.iterator();
	}
	
	public boolean badagoAktorea(String pIzenAbizena){//Aktore bat pasata, listan dagoen esango digu
		boolean dago = false;
		Aktore aktor = null;
		Iterator<Aktore> itr = this.getNireIteradorea();
		while(itr.hasNext() && !dago){
			aktor = itr.next();
			if(aktor.getIzenAbizena().equals(pIzenAbizena)){
				dago = true;}
		}
		return dago;
	}
	
	public void gehituAktorea(Aktore pAktore){
		if(!(this.badagoAktorea(pAktore.getIzenAbizena()))){
			this.lista.addToRear(pAktore);
		}
	}
	
	public void ezabatuAktorea(Aktore pAktore) {
		this.lista.remove(pAktore);	
	}
	
	public int aktoreKopurua() {
		return this.lista.size();
	}
	
	public void erreseteatu() {
		this.lista.first=null;
		this.lista.count=0;
	}
}
