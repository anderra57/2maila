package listasSimples;


public class UnorderedDoubleLinkedList<T> extends DoubleLinkedList<T> implements UnorderedListADT<T> {
	
	public void addToFront(T elem) {
	// hasieran gehitu
		Node<T> berria = new Node<T>(elem);
		if(isEmpty()) {
			first=berria;
			berria.next=berria;
			berria.prev=berria;
		}
		else{
			first.prev.next=berria;
			berria.prev=first.prev;
			first.prev=berria;
			berria.next=first;
			first=berria;	
		}
		count++;
	}

	public void addToRear(T elem) {
	// bukaeran gehitu
		Node<T> berria = new Node<T>(elem);
		if(isEmpty()) {
			first=berria;
			berria.next=berria;
			berria.prev=berria;
		}
		else{
			
			first.prev.next=berria;
			berria.prev=first.prev;
			berria.next=first;
			first.prev=berria;	
			
		}
		count++;
	}
	
	public void addAfter(T elem, T target) { 
		Node<T> berria = new Node<T>(elem);
		Node<T> egungo = first;
		if(isEmpty()) {//Lista hutsa bada
			first=berria;
			berria.next=berria;
			berria.prev=berria;
			count++;
		}
		else{
				boolean aurk = false;
				while(!aurk){
					if(egungo.data.equals(target)){
						aurk = true;
					}else{
						egungo = egungo.next;
					}
				}
				//Momentu honetan elementua sartzeko posizio egokia aurkitu dugu eta elementua txertatuko dugu
				berria.next=egungo.next;
				berria.prev = egungo;
				egungo.next.prev = berria;
				egungo.next = berria;
				count++;				
		}
	}
}
