package listasSimples;

import java.util.Iterator;

public class DoubleLinkedList<T> implements ListADT<T> {

	// Atributuak
	protected Node<T> first; // lehenengoaren erreferentzia
	protected String deskr;  // deskribapena
	protected int count;

	public DoubleLinkedList() {
		first = null;
		deskr = "";
		count = 0;
	}
	
	public void setDeskr(String ize) {
	  deskr = ize;
	}

	public String getDeskr() {
	  return deskr;
	}

	public T removeFirst() {
	// listako lehen elementua kendu da
	// Aurrebaldintza: zerrenda ez da hutsa
		Node<T> aux = first;
		if (first.next==first) { //elementu bakarra
			first=null;
			
		}
		else{
			first.prev.next=first.next;
			first.next.prev=first.prev;
			first=first.next;
		}
		--count;
		
		return aux.data;
	}

	public T removeLast() {
	// listako azken elementua kendu da
	// Aurrebaldintza: zerrenda ez da hutsa
		
		Node<T> aux = first.prev;
		if (first.next==first) { //elementu bakarra
			first=null;
			
		}
		else{
			aux.prev.next=first;
			first.prev=aux.prev;
		}
		--count;
		return aux.data;
    }


	public T remove(T elem) {
	// Aurrebaldintza: zerrenda ez da hutsa
	// Balio hori listan baldin badago, bere lehen agerpena ezabatuko dut. Kendutako objektuaren erreferentzia 
        //  bueltatuko du (null ez baldin badago)
		if(!contains(elem)){return null;}//Elementua lista ez badago
		else{//Elementua lista dago
			Node<T> aux = first.prev;
			boolean badago=false;
			while(!badago){
				aux=aux.next;
				if(aux.data.equals(elem)){
					badago=true;
					if(aux.next.equals(first)){ return removeLast(); }
					else if (aux.equals(first)){ return removeFirst(); }
					else{//listaren erdian dago kendu beharko den elementua
						--count;
						aux.prev.next=aux.next;
						aux.next.prev=aux.prev;
						return aux.data;
					}
				}
			}
		return null; //eclipsek behartuta
		}
    }

	public T first() {
	// listako lehen elementua ematen du
	      if (isEmpty()){
	          return null;
	      }else{ return first.data;}
	}

	public T last() {
	// listako azken elementua ematen du
	      if (isEmpty()){
	          return null;}
	      else{ return first.prev.data;}
	}

	public boolean contains(T elem) {
	// Egiazkoa bueltatuko du aurkituz gero, eta false bestel
		if (isEmpty()){
			return false;}
		else{
			Node<T> aux = first;
			if (first.data.equals(elem)){return true;}//Lehenengo elementua
			boolean badago=false;
			while(!aux.equals(first.prev) && !badago){
				aux=aux.next;
				if(aux.data.equals(elem)){
					badago=true;
				}
			}
			return badago;
		}
	}

	public T find(T elem) {
	// Elementua bueltatuko du aurkituz gero, eta null bestela
		
		if (isEmpty()){
			return null;}
		else{
			if (contains(elem)) {
				//System.out.println("aurkitua");
				return elem;
			}
			else {
				//System.out.println("ez da aurkitu");
				return null;
			}
		}
	}

	public boolean isEmpty() 
	{ return first == null;};
	
	public int size() 
	{ return count;};
	
	/** Return an iterator to the stack that iterates through the items . */ 
	   public Iterator<T> iterator() { return new ListIterator(); } 
	   // an iterator, doesn't implement remove() since it's optional 
	   private class ListIterator implements Iterator<T> { 
		  Node<T> aux = first;
		  boolean listaGuztiaIgarota=false;//lista guztia zeharkatu dugun jakiteko boolean-a
		  public boolean hasNext(){
			  if(isEmpty()){ return false; }
			  else if (aux.equals(first) && listaGuztiaIgarota) {return false;}
			   else {
				   listaGuztiaIgarota=true;
				   return true;
			   }
		   }
		   public T next(){
			   T emaitza = aux.data;
			   aux=aux.next;
			   return emaitza;} 
	   } // private class
		
		
		public void adabegiakInprimatu() {
			System.out.println(this.toString());
		}

		
		@Override
		public String toString() {
			String result = new String();
			Iterator<T> it = iterator();
			while (it.hasNext()) {
				T elem = it.next();
				result = result + "[" + elem.toString() + "] \n";
			}	
			return "\nDoubleLinkedList: \n" + result;
		}

}
