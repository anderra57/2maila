package listasSimples;

import java.io.FileNotFoundException;
import java.io.IOException;

public class ProbaOsoa {

	public static void main(String[] args) throws FileNotFoundException, IOException {
		// TODO Auto-generated method stub		
		UnorderedDoubleLinkedList<Integer> lista = new UnorderedDoubleLinkedList<Integer>();
		System.out.println("4,1,7,3,9,0,8");
		System.out.println("Elementuak listaren atzean txertatu");
		lista.addToRear(4);
		lista.addToRear(1);
		lista.addToRear(7);
		lista.addToRear(3);
		lista.addToRear(9);
		lista.addToRear(0);
		lista.addToRear(8);
		lista.adabegiakInprimatu();
		
		System.out.println("5 elementua, 3 elementuaren atzean txertatu");
		lista.addAfter(5, 3);
		lista.adabegiakInprimatu();
		
		
		System.out.println("6 elementua listaren hasieran txertatu");
		lista.addToFront(6);
		lista.adabegiakInprimatu();
		System.out.println("");
		
		System.out.println("8 elementua listan dagoen jakingo dugu");
		boolean dago = lista.contains(8);
		if(dago){
			System.out.println("BAI");
		}else{
			System.out.println("EZ");
		}
		System.out.println("");
		
		System.out.println("Listako elementu bat bilatuko dugu");
		System.out.println(lista.find(1));
		System.out.println("");
		
		System.out.println("7 elementua listatik borratuko dugu");
		lista.remove(7);
		lista.adabegiakInprimatu();
		
		System.out.println("Listaren lehenengo eta azken elementuak borratuko ditugu");
		System.out.println("Lista hasieran horrela dago");
		lista.adabegiakInprimatu();
		System.out.println("Borratu ondoren");
		lista.removeFirst();
		lista.removeLast();
		lista.adabegiakInprimatu();
		
		System.out.println("Listaren lehenengo eta azken elementuak jasoko ditugu");
		System.out.println("Lista hurrengoa da");
		lista.adabegiakInprimatu();
		System.out.println("Lehenengo elementua:");
		System.out.println(lista.first());
		System.out.println("Azken elementua:");
		System.out.println(lista.last());
		System.out.println("");
		System.out.println(lista.size());
		
		OrderedDoubleLinkedList<Integer> lista2 = new OrderedDoubleLinkedList<Integer>();
		System.out.println("Elementuak ordenean txertatuko dira");
		lista2.add(4);
		lista2.add(1);
		lista2.add(6);
		lista2.add(2);
		lista2.add(7);
		lista2.add(35);
		lista2.add(9);
		lista2.add(3);
		lista2.adabegiakInprimatu();
		
		
		OrderedDoubleLinkedList<Integer> lista3 = new OrderedDoubleLinkedList<Integer>();
		System.out.println("Elementuak ordenean txertatuko dira");
		lista3.add(5);
		lista3.add(89);
		lista3.add(1);
		lista3.add(23);
		lista3.add(4);
		lista3.adabegiakInprimatu();
		
		System.out.println("Lista horrela geratu litzateke:");
		lista3.merge(lista2);
	
        
        UnorderedDoubleLinkedList<Integer> l =new UnorderedDoubleLinkedList<Integer>();
		l.addToRear(1);
		l.addToRear(3);
		l.addToRear(6);
		l.addToRear(7);
		l.addToRear(9);
		l.addToRear(0);
		l.addToRear(20);
		l.addToFront(8);
		l.remove(new Integer(7));

		
		System.out.print(" Lista ...............");
		l.adabegiakInprimatu();
		System.out.println("Elementu-kopurua: " + l.size());
				
		
		System.out.println("Proba Find ...............");
		System.out.println("9? " + l.find(9));
		System.out.println("0? " + l.find(0));
		System.out.println("7? " + l.find(7));

	}
	
}
