package listasSimples;

public class OrderedDoubleLinkedList<T extends Comparable<T>> extends DoubleLinkedList<T> implements OrderedListADT<T> {
	
	
	public void add(T elem){
		Node<T> berria = new Node<T>(elem);
		boolean aurk = false;//elementuaren posizio egokia aurkitzean aktibatutako boolean-a
		boolean buelta = false;//boolean hau erabiliko dugu jakiteko ea lista guztitik pasatu garen ala ez, lista zirkularra delako
		boolean atera = false;//jasotako elementua, jadanik lista balego, ez litzateke listan sartuko eta boolean hau aktibatuko liteke
		if(first == null){//Lista hutsa bada
			count++;
			first = new Node<T>(elem);
			first.next = first;
			first.prev = first;
			
		}else{
			Node<T> egungoa = first;
			while(!aurk && !buelta && !atera){
				if(egungoa.data.compareTo(elem)>0){//elementua listan sartu
					count++;
					if(egungoa == first){//hasieran txertatu
						berria.next =first;
						berria.prev = first.prev;
						first.prev.next = berria;
						first.prev = berria;
						first = berria;
					}else{//erdialdean txertatu
						berria.prev = egungoa.prev;
						berria.next = egungoa;
						egungoa.prev.next = berria;
						egungoa.prev = berria;
					}
					aurk = true;
				}else if(egungoa.data.equals(elem)){//ezer ez txertatu
					atera = true;
				}else{//iteratu
					egungoa = egungoa.next;
				}
				if(egungoa == first){
					buelta = true;
				}
			}
			if(buelta){//bukaeran txertatu
				count++;
				berria.prev = egungoa.prev;
				berria.next = egungoa;
				egungoa.prev.next = berria;
				egungoa.prev = berria;
			}
		}
	}
	
	public void imprimatu (DoubleLinkedList<T> zerrenda){
		Node<T>aux=first;
		if (isEmpty()){
		}
		else{
			while(!aux.equals(first.prev)){
				System.out.print ( aux.data+ " ");  
				aux=aux.next;
			}
		}	
	}

	public void merge(DoubleLinkedList<T> zerrenda){
		OrderedDoubleLinkedList<T> listaB = new OrderedDoubleLinkedList<T>();
		Node<T> act1 = null;
		Node<T> act2 = null;
		Node<T> act3 = null;
		Node<T> berria = null;
		Node<T> firstB = null;
		act1 = zerrenda.first;
		act2 = this.first;
		//BI BOOLEAN JARRIKO DITUGU LISTA OSOA ZEHARKATU DUGUN JAKITEKO, BAT LISTA BAKOITZEKO
		boolean lista1Igarota = false;
		boolean lista2Igarota = false;
		while(!lista1Igarota  && !lista2Igarota){
			if(act1.data.compareTo(act2.data)==1){//BIGARREN ELEMENTUA LEHENENGO ELEMENTUA BAINO HANDIAGOA BADA
				if(firstB==null){//BUKAERA LISTA HUTSA BADA
					firstB = new Node<T>(act2.data);
					firstB.prev = firstB;
					firstB.next = firstB;
					act2 = act2.next;
					act3 = firstB;
				}else{
					berria = new Node<T>(act2.data);//BESTELA, LISTA BERRIKO AZKEN ELEMENTUAREN ATZETIK JARRIKO DUGU NODO BERRIA
					berria.prev = act3;
					berria.next = firstB;
					firstB.prev = berria;
					act3.next = berria;
					act2 = act2.next;
					act3 = act3.next;
				}
				if(act2 == this.first){//IF HAU ERABILIKO DUGU, BIGARREN LISTA OSOA ZEHARKATU DUGUN JAKITEKO
					lista2Igarota = true;
				}
			}else if(act1.data.compareTo(act2.data)==0){//LEHENENGO ELEMENTUA, BIGARREN ELEMENTUAREN BERDINA BADA
				//KASU HONETAN BAKARRIK ZENBAKI BAT JARRIKO DUGU(EZ DUGU ZENBAKIRIK ERREPIKATUKO)
				if(firstB==null){//LISTA HUTSA BALDIN BADA
					firstB = new Node<T>(act1.data);
					firstB.prev = firstB;
					firstB.next = firstB;
					act1 = act1.next;
					act2 = act2.next;
					act3 = firstB;
				}else{
					berria = new Node<T>(act1.data);//BESTELA, LISTA BERRIKO AZKEN ELEMENTUAREN ATZEAN JARRIKO DUGU NODO BERRIA
					berria.prev = act3;
					berria.next = firstB;
					firstB.prev = berria;
					act3.next = berria;
					act1 = act1.next;
					act2 = act2.next;
					act3 = act3.next;
				}
				//KASU HONETAN BI IF JARRIKO DITUGU. AZKEN BATEAN, BI LISTEN ELEMENTUA BERDINA DENEZ, 
				//BI LISTAK ITERATUKO DITUGU ETA BALITEKE LISTA BAT HUTSA EGOTEA
				if(act1 == zerrenda.first){
					lista1Igarota = true;
				}else if(act2 == this.first){
					lista2Igarota = true;
				}else{
				}
			}else{//LEHENENGO ELEMENTUA, BIGARREN ELEMENTUA BAINO HANDIAGOA BADA
				if(firstB==null){//LISTA HUTSA
					firstB = new Node<T>(act1.data);
					firstB.prev = firstB;
					firstB.next = firstB;
					act1 = act1.next;
					act3 = firstB;
				}else{//BESTELA, LISTA BERRIKO AZKEN ELEMENTUAREN ATZEAN JARRIKO DUGU NODO BERRIA
					berria = new Node<T>(act1.data);
					berria.prev = act3;
					berria.next = firstB;
					firstB.prev = berria;
					act3.next = berria;
					act1 = act1.next;
					act3 = act3.next;
				}
				if(act1 == zerrenda.first){//IF HAU ERABILIKO DUGU, LEHENENGO LISTA OSOA ZEHARKATU DUGUN JAKITEKO
					lista1Igarota = true;
				}
			}
		}
		//WHILETIK ATERATZEAN, HIRU KASU POSIBLE EGON DAITEZKE:
		//1.- LEHENENGO LISTA HUTSA EGOTEA
		//2.- BIGARREN LISTA HUTSA EGOTEA
		//3.- BI LISTAK HUTSAK EGOTEA
		if(lista1Igarota && !lista2Igarota){//LEHENENGO KASUAN IZANGO LITZATEKE. LEHENENGO LISTA HUTSA ETA BIGARRENA EZ
			while(!lista2Igarota){//KASU HONETAN, WHILE HAU ERABILIKO DUGU, BIGARREN LISTAN GELDITZEN DIREN ELEMENTU GUZTIAK, LISTA BERRIAREN ATZEAN TXERTATZEKO
				berria = new Node<T>(act2.data);
				berria.prev = act3;
				berria.next = firstB;
				firstB.prev = berria;
				act3.next = berria;
				act2 = act2.next;
				act3 = act3.next;
				if(act2 == this.first){
					lista2Igarota = true;
				}
			}
		}else if(lista2Igarota && !lista1Igarota){//BIGARREN KASUAN IZANGO LITZATEKE. BIGARREN LISTA HUTSA ETA LEHENENGOA EZ
			while(!lista1Igarota){//KASU HONETAN, WHILE HAU ERABILIKO DUGU, LEHENENGO LISTAN GELDITZEN DIREN ELEMENTU GUZTIAK, LISTA BERRIAREN ATZEAN TXERTATZEKO
				berria = new Node<T>(act1.data);
				berria.prev = act3;
				berria.next = firstB;
				firstB.prev = berria;
				act3.next = berria;
				act1 = act1.next;
				act3 = act3.next;
				if(act1 == zerrenda.first){
					lista1Igarota = true;
				}
			}
		}else{//HIRUGARREN KASUAN IZANGO LITZATEKE. BI LISTAK HUTSAK DAUDE
		}//KASU HONETAN EZ GENUKE EZER EGINGO
		listaB.first = firstB;
		listaB.adabegiakInprimatu();
		
}
}
