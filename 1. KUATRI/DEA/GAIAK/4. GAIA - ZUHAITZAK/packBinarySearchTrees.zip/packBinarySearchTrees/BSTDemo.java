package packBinarySearchTrees;

/** 
 * BSTGUI driver for graphical demonstration of a binary search tree.
 * 
 * @author Dr. Lewis
 * @author Dr. Chase
 * @version 1.0, 8/19/08
 */

public class BSTDemo
{
   public static void main(String[] args)
   {
      BSTGUI newDemo = new BSTGUI();
      newDemo.display();
   }
}
